import emulator


if __name__ == "__main__":
    emulator.startConsole()
